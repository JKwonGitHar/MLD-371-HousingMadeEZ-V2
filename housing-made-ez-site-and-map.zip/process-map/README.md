# Process map and website source

Content lives in `map_data.py`. To regenerate after editing:

```
cd process-map
python3 build_map.py     # writes docs/process-map.svg, .png, .pdf (needs: pip install playwright && playwright install chromium)
python3 build_site.py    # writes docs/index.html
```

The website is the `docs/` folder, published with GitHub Pages (Settings > Pages > Deploy from a branch > main > /docs).

The Community section (a prototype) lives in `site_template.html`: sample posts are in the `EXAMPLES` list in its script. Posts people add are saved only in their own browser.

The Harvard Key gate on the Community section is a simulation only (no real authentication, no passwords collected). A real version would need to be set up with Harvard's identity/IT team and a backend.
