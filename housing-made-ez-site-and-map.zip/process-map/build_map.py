"""Builds the process map as SVG (standalone + inline), PNG and PDF.
Usage: python3 build_map.py     (PNG/PDF need: pip install playwright && playwright install chromium)
"""
import textwrap, html, pathlib, sys
from map_data import LANES, STAGES, HUB, NODES

NODE_W, NODE_H = 180, 124
COL0, COL_STEP = 296, 198
NCOLS = len(STAGES)
LANE_X = 268
LANE_W = (COL0 + COL_STEP * (NCOLS - 1) + NODE_W + 24) - LANE_X
LANE_H = 40 + NODE_H + 20
LANE_Y0, LANE_GAP = 90, 12
START_X = 10
W = LANE_X + LANE_W + 10
FONT = "Figtree, Carlito, Calibri, 'Helvetica Neue', Arial, sans-serif"
INK, MUTED, PAIN, HUBGOLD, HUBTINT = "#14213D", "#44506A", "#C8452D", "#E0A526", "#FFF4D6"
TITLE_W, OUT_TITLE_W, SUB_W = 19, 15, 24

esc = html.escape
lane_by_id = {l["id"]: l for l in LANES}
lane_index = {l["id"]: i for i, l in enumerate(LANES)}
VIOL = []

def wrap(text, width, max_lines):
    lines = textwrap.wrap(text, width, break_on_hyphens=False)
    if len(lines) > max_lines:
        VIOL.append(f"{len(lines)} lines (max {max_lines}) @ width {width}: {text}")
    return lines

LANES_BOTTOM = LANE_Y0 + len(LANES) * (LANE_H + LANE_GAP) - LANE_GAP
START_H = {0: 92, 1: 100, 2: 110}
_block = sum(START_H.values()) + 2 * 40
_sy = (LANE_Y0 + LANES_BOTTOM) // 2 - _block // 2
START_Y = {0: _sy, 1: _sy + 92 + 40, 2: _sy + 92 + 40 + 100 + 40}

def node_xy(n):
    if n["lane"] is None:
        return START_X, START_Y[n["row"]], NODE_W, START_H[n["row"]]
    li = lane_index[n["lane"]]
    return COL0 + COL_STEP * n["col"], LANE_Y0 + li * (LANE_H + LANE_GAP) + 40, NODE_W, NODE_H

def node_svg(n):
    x, y, w, h = node_xy(n)
    color = lane_by_id[n["lane"]]["color"] if n["lane"] else INK
    outcome = n.get("outcome")
    if outcome:
        fill = INK if n["lane"] == "unsafe" else color
        txt, sub_c, stroke = "#FFFFFF", "#F1F4F9", fill
    else:
        fill, txt, sub_c, stroke = "#FFFFFF", INK, MUTED, color
    tl = wrap(n["title"], OUT_TITLE_W if outcome else TITLE_W, 2)
    sl = wrap(n["sub"], SUB_W, 3)
    ty = y + 30
    parts = [f'<g class="pm-node" id="node-{n["id"]}" data-id="{n["id"]}" tabindex="0" role="button" '
             f'aria-label="{esc(n["title"])}. {esc(n["sub"])}">',
             f'<rect class="pm-box" x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}" stroke="{stroke}" stroke-width="2"/>']
    for i, line in enumerate(tl):
        parts.append(f'<text x="{x+14}" y="{ty+17*i}" font-size="14.5" font-weight="700" fill="{txt}">{esc(line)}</text>')
    sy = ty + 17 * (len(tl) - 1) + 24
    for i, line in enumerate(sl):
        parts.append(f'<text x="{x+14}" y="{sy+15*i}" font-size="12.5" fill="{sub_c}">{esc(line)}</text>')
    if outcome:
        cx, cy = x + w - 22, y + 22
        parts.append(f'<circle cx="{cx}" cy="{cy}" r="11" fill="#FFFFFF"/>')
        d = "M-5 0 L-1.5 4 L5 -4" if outcome == "check" else "M-5 0 H5 M1 -4 L5 0 L1 4"
        c = color if outcome == "check" else INK
        parts.append(f'<path transform="translate({cx} {cy})" d="{d}" fill="none" stroke="{c}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>')
    if n.get("pain"):
        cx, cy = x + w - 2, y + 2
        parts.append(f'<circle cx="{cx}" cy="{cy}" r="11" fill="{PAIN}" stroke="#FFFFFF" stroke-width="2"/>'
                     f'<text x="{cx}" y="{cy+5}" font-size="14" font-weight="800" fill="#FFFFFF" text-anchor="middle">!</text>')
        parts.append(f'<rect x="{cx-52}" y="{cy-9}" width="34" height="18" rx="9" fill="{HUBGOLD}" stroke="#FFFFFF" stroke-width="2"/>'
                     f'<text x="{cx-35}" y="{cy+4}" font-size="11" font-weight="800" fill="{INK}" text-anchor="middle">EZ</text>')
    parts.append('</g>')
    return "\n".join(parts)

def build_svg(with_title=False):
    off = 76 if with_title else 0
    hy = LANES_BOTTOM + 20
    hh = 120
    ly = hy + hh + 28
    H = ly + 34 + off
    o = []
    o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
             f'aria-labelledby="pm-title pm-desc" class="pm-svg" font-family="{FONT}">')
    o.append('<title id="pm-title">International student housing journey: seven pathways</title>')
    o.append('<desc id="pm-desc">From the student\'s point of view: from admission to a signed lease or a short-term home through Harvard University Housing, '
             'Harvard sublets, a licensed broker, a safe private landlord, roommates or temporary housing, or what happens after an unsafe landlord or scam, '
             'with the Housing Made EZ hub resources at each stage.</desc>')
    o.append('<defs>')
    for lid, col in [("n", MUTED)] + [(l["id"], l["color"]) for l in LANES]:
        o.append(f'<marker id="arr-{lid}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                 f'<path d="M1 1 L9 5 L1 9" fill="none" stroke="{col}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></marker>')
    o.append('</defs>')
    o.append(f'<rect width="{W}" height="{H}" fill="#FFFFFF"/>')
    if with_title:
        o.append(f'<text x="10" y="34" font-size="26" font-weight="800" fill="{INK}">International student housing journey</text>')
        o.append(f'<text x="10" y="58" font-size="14" fill="{MUTED}">Seven pathways from admission to a home, or what to do when it goes wrong. Student point of view.</text>')
    o.append(f'<g transform="translate(0 {off})">')

    def pill(cx, label):
        w = len(label) * 6.3 + 22
        return (f'<rect x="{cx-w/2:.1f}" y="46" width="{w:.1f}" height="22" rx="11" fill="{HUBTINT}" stroke="{HUBGOLD}" stroke-width="1.5"/>'
                f'<text x="{cx}" y="61" font-size="11.5" font-weight="700" fill="{INK}" text-anchor="middle">{esc(label)}</text>')
    cx0 = START_X + NODE_W / 2
    o.append(f'<text x="{cx0}" y="34" font-size="13" font-weight="700" fill="{MUTED}" text-anchor="middle">Start</text>')
    o.append(pill(cx0, HUB[0][0]))
    for i, st in enumerate(STAGES):
        cx = COL0 + COL_STEP * i + NODE_W / 2
        o.append(f'<text x="{cx}" y="34" font-size="13" font-weight="700" fill="{MUTED}" text-anchor="middle">{esc(st)}</text>')
        o.append(pill(cx, HUB[i + 1][0]))

    start_nodes = [n for n in NODES if n["lane"] is None]
    px = START_X + NODE_W
    py = START_Y[2] + START_H[2] / 2
    for li, lane in enumerate(LANES):
        ly0 = LANE_Y0 + li * (LANE_H + LANE_GAP)
        c = lane["color"]
        o.append(f'<g class="pm-lane pm-lane-{lane["id"]}">')
        o.append(f'<rect x="{LANE_X}" y="{ly0}" width="{LANE_W}" height="{LANE_H}" rx="14" fill="{lane["tint"]}" stroke="{c}" stroke-opacity=".45"/>')
        o.append(f'<text x="{LANE_X+20}" y="{ly0+27}" font-size="15" font-weight="800" fill="{c}">{esc(lane["label"])}</text>')
        o.append(f'<text x="{LANE_X+LANE_W-18}" y="{ly0+27}" font-size="12.5" fill="{MUTED}" text-anchor="end">{esc(lane["tag"])}</text>')
        ln = [n for n in NODES if n["lane"] == lane["id"]]
        mid = ly0 + 40 + NODE_H / 2
        tx = COL0 - 4
        o.append(f'<path d="M{px} {py} C {px+60} {py}, {tx-60} {mid}, {tx} {mid}" fill="none" stroke="{c}" stroke-width="2" marker-end="url(#arr-{lane["id"]})"/>')
        for a, b in zip(ln, ln[1:]):
            ax, _, aw, _ = node_xy(a)
            bx, _, _, _ = node_xy(b)
            o.append(f'<line x1="{ax+aw}" y1="{mid}" x2="{bx-4}" y2="{mid}" stroke="{c}" stroke-width="2.2" marker-end="url(#arr-{lane["id"]})"/>')
        for n in ln:
            o.append(node_svg(n))
        o.append('</g>')

    o.append('<g class="pm-start">')
    for a, b in zip(start_nodes, start_nodes[1:]):
        ax, ay, aw, ah = node_xy(a); bx, by, bw, bh = node_xy(b)
        o.append(f'<line x1="{ax+aw/2}" y1="{ay+ah}" x2="{bx+bw/2}" y2="{by-4}" stroke="{MUTED}" stroke-width="2.2" marker-end="url(#arr-n)"/>')
    for n in start_nodes:
        o.append(node_svg(n))
    o.append('</g>')

    o.append(f'<g class="pm-hub"><rect x="{START_X}" y="{hy}" width="{LANE_X+LANE_W-START_X}" height="{hh}" rx="14" fill="{HUBTINT}" stroke="{HUBGOLD}" stroke-width="1.5"/>')
    o.append(f'<text x="{START_X+14}" y="{hy+26}" font-size="15" font-weight="800" fill="{INK}">Housing Made EZ hub: the resources we plan to offer at each step</text>')
    xs = [START_X + 14] + [COL0 + COL_STEP * i for i in range(NCOLS)]
    for x, (t, d) in zip(xs, HUB):
        o.append(f'<text x="{x}" y="{hy+56}" font-size="13.5" font-weight="700" fill="{INK}">{esc(t)}</text>')
        for i, line in enumerate(wrap(d, 24, 3)):
            o.append(f'<text x="{x}" y="{hy+75+15*i}" font-size="12.5" fill="{MUTED}">{esc(line)}</text>')
    for x in xs[1:]:
        o.append(f'<line x1="{x-11}" y1="{hy+40}" x2="{x-11}" y2="{hy+hh-12}" stroke="{HUBGOLD}" stroke-opacity=".5" stroke-dasharray="3 4"/>')
    o.append('</g>')

    o.append(f'<g class="pm-legend" font-size="12.5" fill="{MUTED}">')
    o.append(f'<circle cx="{START_X+11}" cy="{ly}" r="11" fill="{PAIN}" stroke="#fff" stroke-width="2"/><text x="{START_X+11}" y="{ly+5}" font-size="14" font-weight="800" fill="#fff" text-anchor="middle">!</text>')
    o.append(f'<text x="{START_X+30}" y="{ly+4}">Common pain point</text>')
    o.append(f'<rect x="{START_X+190}" y="{ly-10}" width="34" height="20" rx="5" fill="{INK}"/><text x="{START_X+234}" y="{ly+4}">Outcome (housed, or next steps)</text>')
    o.append(f'<rect x="{START_X+470}" y="{ly-10}" width="34" height="20" rx="5" fill="{HUBTINT}" stroke="{HUBGOLD}" stroke-width="1.5"/><text x="{START_X+514}" y="{ly+4}">Hub resource for each stage</text>')
    o.append(f'<rect x="{START_X+780}" y="{ly-9}" width="34" height="18" rx="9" fill="{HUBGOLD}" stroke="#fff" stroke-width="2"/><text x="{START_X+797}" y="{ly+4}" font-size="11" font-weight="800" fill="{INK}" text-anchor="middle">EZ</text>')
    o.append(f'<text x="{START_X+824}" y="{ly+4}">The hub targets this pain point</text>')
    o.append('</g>')
    o.append('</g></svg>')
    return "\n".join(o), W, H

if __name__ == "__main__":
    out = pathlib.Path(__file__).resolve().parent.parent / "docs"
    out.mkdir(exist_ok=True)
    static, sw, sh = build_svg(with_title=True)
    inline, _, _ = build_svg(with_title=False)
    if VIOL:
        print("TEXT TOO LONG:"); print("\n".join(sorted(set(VIOL)))); sys.exit(1)
    (out / "process-map.svg").write_text(static, encoding="utf-8")
    (pathlib.Path(__file__).parent / "map_inline.svg").write_text(inline, encoding="utf-8")
    print("SVG written", sw, "x", sh)
    if "--no-raster" in sys.argv:
        sys.exit()
    from playwright.sync_api import sync_playwright
    page_html = f'<!doctype html><meta charset="utf-8"><style>html,body{{margin:0;background:#fff}}svg{{display:block}}</style>{static}'
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": sw, "height": sh}, device_scale_factor=2)
        pg.set_content(page_html)
        pg.screenshot(path=str(out / "process-map.png"), full_page=True)
        pg.pdf(path=str(out / "process-map.pdf"), width=f"{sw}px", height=f"{sh}px", print_background=True, page_ranges="1")
        b.close()
    print("PNG + PDF written")
