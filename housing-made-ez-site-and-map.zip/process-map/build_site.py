"""Assembles docs/index.html: inlines the map SVG and node details into the page template.
Run build_map.py first.
"""
import json, pathlib
from map_data import NODES, S
here = pathlib.Path(__file__).resolve().parent
svg = (here / "map_inline.svg").read_text(encoding="utf-8")
tpl = (here / "site_template.html").read_text(encoding="utf-8")
keys = ["id", "lane", "title", "detail", "watch", "hub", "src"]
data = [{k: n.get(k) for k in keys} for n in NODES]
static = (here.parent / "docs" / "process-map.svg").read_text(encoding="utf-8")
page = tpl.replace("<!--STATIC-->", static).replace("<!--MAP-->", svg).replace("/*NODES*/", json.dumps(data, ensure_ascii=False)).replace("/*SRC*/", json.dumps({k: list(v) for k, v in S.items()}, ensure_ascii=False))
out = here.parent / "docs" / "index.html"
out.write_text(page, encoding="utf-8")
print("Wrote", out, f"({len(page)//1024} KB)")
